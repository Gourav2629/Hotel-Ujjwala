import React, { useState } from "react";

export default function BookingPage() {
  const [selectedDate, setSelectedDate] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    mobile: "",
    eventType: "Marriage",
    timeSlot: "Day",
    plates: 0,
    extraDJ: false,
    extraDecor: false,
    jaimalaStage: false,
    fogAnar: false,
    rampType: "None",
    message: ""
  });

  const getBasePrice = () => {
    if (formData.eventType === "Marriage") {
      return formData.timeSlot === "Night" ? 191000 : 181000;
    } else if (formData.eventType === "Birthday") {
      return 40000;
    } else {
      return 30000;
    }
  };

  const getExtrasPrice = () => {
    let total = 0;
    if (formData.plates > 0) total += formData.plates * 1000;
    if (formData.extraDJ) total += 5000;
    if (formData.extraDecor) total += 8000;
    if (formData.jaimalaStage) total += 7000;
    if (formData.fogAnar) total += 6000;
    if (formData.rampType === "Mirror") total += 10000;
    if (formData.rampType === "Silver") total += 8000;
    if (formData.rampType === "Golden") total += 12000;
    return total;
  };

  const totalCost = getBasePrice() + getExtrasPrice();
  const minBooking = Math.min(61000, Math.max(31000, totalCost * 0.2));

  const handleBooking = () => {
    alert(
      `📅 Booking Details:\n
      Name: ${formData.name}\n
      Mobile: ${formData.mobile}\n
      Date: ${selectedDate}\n
      Event: ${formData.eventType} (${formData.timeSlot})\n
      Plates: ${formData.plates}\n
      Extras: DJ=${formData.extraDJ}, Decor=${formData.extraDecor}, Jaimala=${formData.jaimalaStage}, Fog+Anar=${formData.fogAnar}, Ramp=${formData.rampType}\n
      Total: ₹${totalCost}\n
      Min Advance: ₹${minBooking}`
    );
  };

  return (
    <div style={{ padding: 20, maxWidth: 800, margin: "auto", fontFamily: "Arial" }}>
      <h1 style={{ textAlign: "center" }}>Ujjwala Resort & Banquet</h1>
      <p style={{ textAlign: "center", color: "gray" }}>Book your special day with ease!</p>
      <div>
        <label>Select Date: </label>
        <input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} />
      </div>
      <input placeholder="Your Name" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} style={{ display: "block", marginTop: 10, width: "100%" }} />
      <input placeholder="Mobile Number" value={formData.mobile} onChange={(e) => setFormData({ ...formData, mobile: e.target.value })} style={{ display: "block", marginTop: 10, width: "100%" }} />
      <label>Event Type:</label>
      <select value={formData.eventType} onChange={(e) => setFormData({ ...formData, eventType: e.target.value })}>
        <option value="Marriage">Marriage</option>
        <option value="Birthday">Birthday</option>
        <option value="Other">Other</option>
      </select>
      <label>Time Slot:</label>
      <select value={formData.timeSlot} onChange={(e) => setFormData({ ...formData, timeSlot: e.target.value })}>
        <option value="Day">Day</option>
        <option value="Night">Night</option>
      </select>
      <input type="number" placeholder="Number of Plates (₹1000/plate)" value={formData.plates} onChange={(e) => setFormData({ ...formData, plates: parseInt(e.target.value || 0) })} style={{ display: "block", marginTop: 10, width: "100%" }} />
      <div style={{ marginTop: 10 }}>
        <label><input type="checkbox" checked={formData.extraDJ} onChange={(e) => setFormData({ ...formData, extraDJ: e.target.checked })}/> DJ (₹5000)</label><br />
        <label><input type="checkbox" checked={formData.extraDecor} onChange={(e) => setFormData({ ...formData, extraDecor: e.target.checked })}/> Extra Decoration (₹8000)</label><br />
        <label><input type="checkbox" checked={formData.jaimalaStage} onChange={(e) => setFormData({ ...formData, jaimalaStage: e.target.checked })}/> Jaimala Stage (₹7000)</label><br />
        <label><input type="checkbox" checked={formData.fogAnar} onChange={(e) => setFormData({ ...formData, fogAnar: e.target.checked })}/> Fog + Anar Entry (₹6000)</label>
      </div>
      <label>Ramp Type:</label>
      <select value={formData.rampType} onChange={(e) => setFormData({ ...formData, rampType: e.target.value })} style={{ width: "100%" }}>
        <option value="None">No Ramp</option>
        <option value="Mirror">Mirror Ramp (₹10000)</option>
        <option value="Silver">Silver Ramp (₹8000)</option>
        <option value="Golden">Golden Ramp (₹12000)</option>
      </select>
      <textarea placeholder="Additional Message" value={formData.message} onChange={(e) => setFormData({ ...formData, message: e.target.value })} style={{ width: "100%", marginTop: 10 }} />
      <p style={{ marginTop: 10 }}>💰 <strong>Total Charges:</strong> ₹{totalCost}</p>
      <p>🔐 <strong>Min Advance Required:</strong> ₹{minBooking}</p>
      <button onClick={handleBooking} style={{ marginTop: 10, padding: 10, backgroundColor: "#000", color: "#fff", border: "none", width: "100%" }}>Book Now</button>
      <p style={{ marginTop: 20, textAlign: "center", color: "gray" }}>For help, contact: <strong>7668235102</strong></p>
    </div>
  );
}