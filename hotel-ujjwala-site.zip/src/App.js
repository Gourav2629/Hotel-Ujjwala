import BookingPage from './BookingPage';
export default function App() { return <BookingPage />; }